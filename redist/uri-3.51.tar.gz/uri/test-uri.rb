# $Id: test-uri.rb,v 2.1 2000/05/07 16:36:51 rgt Exp $

require 'uri'

include URIModule

BASE = 'base:'.freeze
ABSOLUTE = 'absolute:'.freeze
RELATIVE = 'relative:'.freeze

$base = nil
$file = File.new('in-uri.txt')

def read_line
  while (line = $file.gets)
    next if line[0] == ?# or line == $/
    return line
  end
  nil
end

base = current = nil
while (line = read_line)
  type, input, answer = line.split
  if answer.nil?
    answer = input
  end
  type.strip!
  input.strip!
  answer.strip!
  begin
    case type
    when BASE
      base = current = URI.create(input)
    when RELATIVE
      current = base.create_relative_uri(input)
    when ABSOLUTE
      current = URI.create(input)
    else
      raise 'unknown type'
    end
  rescue URIError
    printf '%s: %s%s', $., $!, ($/)
  end
  if current.to_s != answer
    printf 'ERROR:%s: %s <=> %s%s', $., current.to_s, answer, ($/)
  end
end

# test for URI.escape

# uric          = reserved | unreserved | escaped
# reserved      = ";" | "/" | "?" | ":" | "@" | "&" | "=" | "+" |
#                "$" | "," | "[" | "]"
# unreserved    = alphanum | mark
# mark          = "-" | "_" | "." | "!" | "~" | "*" | "'" |
#                 "(" | ")"

uric = ";" << "/" << "?" << ":" << "@" << "&" << "=" << "+" << "$" << "," << "[" << "]" << "-" << "_" << "." << "!" << "~" << "*" << "'" << "(" << ")" #'
0.upto 9 do |i| uric << i.to_s end
?A.upto ?Z do |a| uric << a.chr end
?a.upto ?z do |a| uric << a.chr end
uric_a = uric.split(//).sort
uric =  uric_a.join

buff = ''
1.upto 255 do |c|
  str = URI.escape(c.chr)
  if str.size == 1
    buff << str
  end
end

if uric == buff
  puts "OK: URI.escape"
else
  puts "ERROR: URI.escape"
end
puts uric
puts buff
